package cl.bytnet.best_travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
