package cl.bytnet.best_travel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestTravelApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestTravelApplication.class, args);
	}

}
