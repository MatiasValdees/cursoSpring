package com.debuggeando_ideas.best_travel.infraestructure.abstract_services;

public interface ReportService {

    byte[] readFile();
}
