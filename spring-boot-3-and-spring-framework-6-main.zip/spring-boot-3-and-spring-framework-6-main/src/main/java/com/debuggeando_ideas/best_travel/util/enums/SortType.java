package com.debuggeando_ideas.best_travel.util.enums;

public enum SortType {
    LOWER,
    UPPER,
    NONE
}
