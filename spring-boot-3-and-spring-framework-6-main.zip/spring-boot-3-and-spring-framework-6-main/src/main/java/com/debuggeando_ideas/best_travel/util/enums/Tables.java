package com.debuggeando_ideas.best_travel.util.enums;

public enum Tables {
    customer,
    fly,
    hotel,
    ticket,
    tour,
    reservation
}
